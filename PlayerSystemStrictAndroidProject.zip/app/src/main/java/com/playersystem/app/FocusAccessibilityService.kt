package com.playersystem.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class FocusAccessibilityService : AccessibilityService() {
    private var lastBlockedAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !FocusPrefs.isFocusEnabled(this)) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui") return

        val youtube = pkg == "com.google.android.youtube"
        val blockedPackage = pkg == "com.discord" || pkg == "com.brave.browser"

        // Whole YouTube app is blocked during focus except during an explicitly started lecture session.
        // This cannot selectively identify or reliably block Shorts inside YouTube.
        val shouldBlock = blockedPackage || (youtube && !FocusPrefs.isLectureAllowed(this))
        if (shouldBlock) {
            val now = System.currentTimeMillis()
            if (now - lastBlockedAt < 900) return
            lastBlockedAt = now
            performGlobalAction(GLOBAL_ACTION_HOME)
            FocusPrefs.incrementBlocked(this)
        }
    }

    override fun onInterrupt() {}
}

object FocusPrefs {
    private const val PREFS = "player_system"
    fun isFocusEnabled(c: android.content.Context) =
        c.getSharedPreferences(PREFS, 0).getBoolean("strict_focus", false)
    fun isLectureAllowed(c: android.content.Context) =
        c.getSharedPreferences(PREFS, 0).getBoolean("lecture_allowed", false)
    fun setFocus(c: android.content.Context, enabled: Boolean) {
        c.getSharedPreferences(PREFS, 0).edit().putBoolean("strict_focus", enabled).apply()
    }
    fun setLecture(c: android.content.Context, enabled: Boolean) {
        c.getSharedPreferences(PREFS, 0).edit().putBoolean("lecture_allowed", enabled).apply()
    }
    fun incrementBlocked(c: android.content.Context) {
        val p = c.getSharedPreferences(PREFS, 0)
        p.edit().putInt("blocked_attempts", p.getInt("blocked_attempts", 0) + 1).apply()
    }
}
