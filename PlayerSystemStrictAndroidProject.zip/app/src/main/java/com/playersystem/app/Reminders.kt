package com.playersystem.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.util.Calendar

data class R(val id: Int, val label: String, val def: Int, val quest: String, val text: String)

object Rem {
    private fun fm(x: Int) = Math.floorMod(x, 1440)

    fun list(c: Context): List<R> {
        val s = Store.sch(c); val co = Store.cOn(c); val k = Store.plan(c).kcal
        val tm = mapOf(
            3 to s[0] - 45, 4 to s[1] + 15,
            10 to (if (co) s[2] - 45 else s[1] + 180),
            5 to (if (co) s[3] + 30 else s[1] + 300).coerceIn(1170, 1290)
        )
        val dn = tm[5]!!
        val meals = Store.MEALS.map { R(it.rid, it.label, fm(tm[it.rid]!!), "diet", "${it.label}: about ${k * it.pct / 100} kcal. ${it.food}") }
        val s1 = (if (co) minOf(s[1] + 75, s[2] - 60) else s[1] + 75).coerceAtLeast(s[1] + 30)
        return meals + listOf(
            R(1, "Workout", fm(maxOf(300, s[0] - 150)), "workout", "Gate open. Start the workout tracker in QUESTS."),
            R(2, "Study block", fm(s1), "study", "Study time. Start a Focus session now."),
            R(8, "Evening study", fm(maxOf(dn + 60, 1260).coerceAtMost(1320)), "study", "Second study block. Start Focus."),
            R(6, "Water", fm(s[0] + 150), "water", "Drink a glass of water and log it."),
            R(7, "Water", fm(s[1] + 120), "water", "Water check. Log your glass."),
            R(9, "Sleep", 1350, "sleep", "Lights out soon. Claim your sleep quest.")
        )
    }

    fun minutes(c: Context, r: R) = r.def

    fun scheduleAll(c: Context) = list(c).forEach { schedule(c, it) }

    fun schedule(c: Context, r: R) {
        val m = minutes(c, r)
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, m / 60); set(Calendar.MINUTE, m % 60); set(Calendar.SECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        val pi = PendingIntent.getBroadcast(
            c, r.id, Intent(c, ReminderReceiver::class.java).putExtra("id", r.id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        c.getSystemService(AlarmManager::class.java)
            .setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val r = Rem.list(c).firstOrNull { it.id == i.getIntExtra("id", 0) } ?: return
        Rem.schedule(c, r)
        if (Store.done(c, r.quest)) return
        Store.MEALS.firstOrNull { it.rid == r.id }?.let { if (Store.logged(c, it.id)) return }
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("sys", "System Alerts", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        nm.notify(
            r.id,
            Notification.Builder(c, "sys")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("[SYSTEM] ${r.label}")
                .setContentText(r.text)
                .setStyle(Notification.BigTextStyle().bigText(r.text))
                .setContentIntent(open)
                .setAutoCancel(true)
                .build()
        )
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { Rem.scheduleAll(c) }
}
