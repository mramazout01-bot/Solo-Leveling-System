package com.playersystem.app

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.app.usage.UsageStatsManager
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import java.util.Calendar

class MainActivity : Activity() {
    private val CARD = 0xFF0B1220.toInt()
    private val ACC = 0xFF2EA8FF.toInt()
    private val TXT = 0xFFE6F1FF.toInt()
    private val DIM = 0xFF7F93B2.toInt()
    private val RED = 0xFFFF4D5E.toInt()
    private lateinit var body: LinearLayout
    private lateinit var tabs: LinearLayout
    private var tab = 0

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun fmt(m: Int) = "%02d:%02d".format(Math.floorMod(m, 1440) / 60, Math.floorMod(m, 1440) % 60)
    private fun nowMin(): Int { val c = Calendar.getInstance(); return c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE) }

    private fun tv(s: String, sz: Float = 14f, col: Int = TXT, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.text = s; v.textSize = sz; v.setTextColor(col); v.letterSpacing = 0.04f
        v.typeface = Typeface.create(Typeface.MONOSPACE, if (bold) Typeface.BOLD else Typeface.NORMAL)
        v.setPadding(0, dp(4), 0, dp(4))
        return v
    }

    private fun glow(fill: Int, stroke: Int): LayerDrawable {
        val o = GradientDrawable()
        o.setColor(0); o.setStroke(dp(5), (stroke and 0x00FFFFFF) or 0x33000000); o.cornerRadius = dp(10).toFloat()
        val i = GradientDrawable()
        i.setColor(fill); i.setStroke(dp(1), stroke); i.cornerRadius = dp(8).toFloat()
        val l = LayerDrawable(arrayOf(o, i))
        l.setLayerInset(1, dp(3), dp(3), dp(3), dp(3))
        return l
    }

    private fun btn(s: String, f: () -> Unit): Button {
        val b = Button(this)
        b.text = s; b.isAllCaps = false; b.setTextColor(TXT); b.textSize = 13f
        b.typeface = Typeface.MONOSPACE
        b.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        b.background = glow(0xFF10223D.toInt(), ACC)
        b.setOnClickListener { f() }
        return b
    }

    private fun lp(top: Int = 6): LinearLayout.LayoutParams {
        val l = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        l.topMargin = dp(top)
        return l
    }

    private fun LinearLayout.t(s: String, sz: Float = 14f, col: Int = TXT, bold: Boolean = false) = addView(tv(s, sz, col, bold))
    private fun LinearLayout.b(s: String, f: () -> Unit) = addView(btn(s, f), lp())

    private fun card(title: String): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = glow(CARD, ACC)
        c.setPadding(dp(18), dp(14), dp(18), dp(16))
        c.addView(tv("[ $title ]", 12f, ACC, true))
        body.addView(c, lp(14))
        return c
    }

    private fun head(title: String, sub: String) {
        val s = tv("[ SYSTEM ]", 12f, ACC, true)
        body.addView(s)
        val a = ObjectAnimator.ofFloat(s, "alpha", 1f, 0.35f)
        a.duration = 1400; a.repeatCount = ValueAnimator.INFINITE; a.repeatMode = ValueAnimator.REVERSE; a.start()
        body.addView(tv(title, 26f, TXT, true))
        body.addView(tv(sub, 12f, DIM))
    }

    private fun popup(m: String) {
        val v = LinearLayout(this)
        v.orientation = LinearLayout.VERTICAL
        v.setPadding(dp(24), dp(20), dp(24), dp(20))
        v.background = glow(CARD, ACC)
        v.addView(tv("[ SYSTEM ]", 13f, ACC, true))
        v.addView(tv(m, 18f, TXT, true))
        val d = AlertDialog.Builder(this).setView(v).create()
        d.window?.setBackgroundDrawable(ColorDrawable(0))
        v.addView(btn("OK") { d.dismiss() }, lp(14))
        d.show()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = 0xFF03050A.toInt()
        window.navigationBarColor = 0xFF070B14.toInt()
        Rem.scheduleAll(this)
        val frame = LinearLayout(this)
        frame.orientation = LinearLayout.VERTICAL
        frame.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFF03050A.toInt(), 0xFF0A1428.toInt()))
        val sv = ScrollView(this)
        body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(dp(16), dp(36), dp(16), dp(16))
        sv.addView(body)
        frame.addView(sv, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        tabs = LinearLayout(this)
        tabs.setBackgroundColor(0xFF070B14.toInt())
        frame.addView(tabs, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        setContentView(frame)
    }

    override fun onResume() { super.onResume(); render() }

    private fun render() {
        Store.rollover(this); Store.settle(this)
        body.removeAllViews()
        when (tab) { 0 -> status(); 1 -> quests(); 2 -> diet(); 3 -> focus(); else -> setup() }
        tabs.removeAllViews()
        listOf("STATUS", "QUESTS", "DIET", "FOCUS", "SETUP").forEachIndexed { i, n ->
            val v = TextView(this)
            v.text = n; v.textSize = 11f; v.gravity = Gravity.CENTER
            v.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            v.setPadding(0, dp(14), 0, dp(14))
            v.setTextColor(if (i == tab) ACC else DIM)
            if (i == tab) v.setBackgroundColor(0xFF10223D.toInt())
            v.setOnClickListener { tab = i; render() }
            tabs.addView(v, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        }
        val m = Store.p(this).getString("msg", "") ?: ""
        if (m.isNotEmpty()) { Store.p(this).edit().putString("msg", "").apply(); popup(m) }
    }

    private fun rankCol(r: String) = when (r) {
        "E" -> 0xFF9AA7B8.toInt(); "D" -> 0xFF4CD964.toInt(); "C" -> 0xFF2EA8FF.toInt()
        "B" -> 0xFFB26BFF.toInt(); "A" -> 0xFFFFB02E.toInt(); else -> 0xFFFF4D5E.toInt()
    }

    // ---------- STATUS ----------
    private fun status() {
        head("PLAYER STATUS", "Arise. Complete your quests. Stay focused.")
        val xp = Store.xp(this); val lv = Store.level(this); val rk = Store.rank(lv)
        val c = card("PLAYER")
        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        val badge = TextView(this)
        badge.text = rk; badge.textSize = 34f; badge.gravity = Gravity.CENTER
        badge.setTextColor(rankCol(rk)); badge.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL; bg.setColor(0xFF05070D.toInt()); bg.setStroke(dp(3), rankCol(rk))
        badge.background = bg
        top.addView(badge, LinearLayout.LayoutParams(dp(76), dp(76)))
        val info = LinearLayout(this)
        info.orientation = LinearLayout.VERTICAL; info.setPadding(dp(16), 0, 0, 0)
        info.addView(tv("LEVEL $lv", 26f, TXT, true))
        info.addView(tv("RANK $rk  •  XP ${xp % 100}/100", 12f, DIM))
        top.addView(info)
        c.addView(top)
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        bar.max = 100
        bar.progressTintList = ColorStateList.valueOf(ACC)
        c.addView(bar, lp(12))
        ObjectAnimator.ofInt(bar, "progress", 0, xp % 100).setDuration(900).start()
        listOf("STR", "INT", "VIT").forEach { s ->
            val v = minOf(Store.stat(this, s), 10)
            c.t("$s  ${"▰".repeat(v)}${"▱".repeat(10 - v)}  ${Store.stat(this, s)}", 14f, ACC, true)
        }
        val a = card("TODAY")
        a.t("Focus completed: ${Store.fm(this)} / 120 min")
        a.t("Distractions blocked: ${Store.blocks(this)}")
        val pen = Store.gi(this, "pen", 0)
        if (pen > 0) a.t("Yesterday's penalty: -$pen XP", 13f, RED, true)
        a.t(if (Store.inSchool(this)) "SCHOOL/COACHING: gates sealed" else "Schedule: free time", 13f, if (Store.inSchool(this)) RED else DIM, true)

        val m = card("SCREEN TIME TODAY")
        try {
            val um = getSystemService(UsageStatsManager::class.java)
            val cal = Calendar.getInstance()
            cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
            val top6 = um.queryAndAggregateUsageStats(cal.timeInMillis, System.currentTimeMillis()).values
                .filter { it.totalTimeInForeground > 60000 && it.packageName != packageName && packageManager.getLaunchIntentForPackage(it.packageName) != null }
                .sortedByDescending { it.totalTimeInForeground }.take(6)
            if (top6.isEmpty()) m.t("No data. Grant Usage Access in SETUP.", 12f, DIM)
            top6.forEach { u ->
                val mi = u.totalTimeInForeground / 60000
                val n = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(u.packageName, 0)).toString() } catch (e: Exception) { u.packageName }
                m.t("$n   ${mi / 60}h ${mi % 60}m")
            }
        } catch (e: Exception) { m.t("Usage data unavailable.", 12f, DIM) }
    }

    // ---------- QUESTS (verified) ----------
    private fun quests() {
        head("DAILY QUESTS", "Every quest is verified. Fake claims cost XP.")
        val p = Store.p(this)
        Store.QUESTS.forEach { q ->
            val c = card(q.title.substringBefore(':').uppercase() + "  +${q.xp} XP")
            c.t(q.title.substringAfter(": "), 13f, DIM)
            if (Store.done(this, q.id)) { c.t("✔ COMPLETE", 16f, ACC, true); return@forEach }
            when (q.id) {
                "workout" -> {
                    val ws = p.getLong("wstart", 0L)
                    if (ws == 0L) c.b("START WORKOUT (steps are tracked)") { startWorkout() }
                    else {
                        c.t("Tracking: ${(System.currentTimeMillis() - ws) / 60000} min", 14f, RED, true)
                        c.b("FINISH & VERIFY") { finishWorkout() }
                    }
                }
                "study" -> c.t("Focus ${Store.fm(this)} / 120 min. Run sessions in FOCUS tab. Quitting early cancels credit.", 13f, ACC)
                "diet" -> c.t("Meals logged: ${Store.MEALS.count { Store.logged(this, it.id) }} / 4. Log each in DIET tab, inside its time window.", 13f, ACC)
                "water" -> {
                    val need = Math.ceil(Store.plan(this).waterMl / 250.0).toInt()
                    c.t("${Store.glasses(this)} / $need glasses (250 ml). One log per 20 min.", 13f, ACC)
                    c.b("+1 GLASS") {
                        val last = p.getLong("lw", 0L)
                        if (System.currentTimeMillis() - last < 20 * 60000L) {
                            Store.addXp(this, -5); popup("TOO FAST.\nYou cannot drink that quickly. -5 XP")
                        } else {
                            p.edit().putInt("w_${Store.today()}", Store.glasses(this) + 1).putLong("lw", System.currentTimeMillis()).apply()
                            if (Store.glasses(this) >= need) Store.complete(this, "water")
                        }
                        render()
                    }
                }
                "sleep" -> c.b("CLAIM SLEEP") {
                    if (nowMin() in 1260..1410) Store.complete(this, "sleep")
                    else { Store.addXp(this, -5); popup("OUTSIDE SLEEP WINDOW\nClaim between 21:00 and 23:30. -5 XP") }
                    render()
                }
            }
        }
    }

    private fun readSteps(cb: (Float) -> Unit) {
        val sm = getSystemService(SensorManager::class.java)
        val sen = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
        if (sen == null) { cb(-1f); return }
        sm.registerListener(object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) { sm.unregisterListener(this); cb(e.values[0]) }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }, sen, SensorManager.SENSOR_DELAY_NORMAL)
    }

    private fun startWorkout() {
        if (Build.VERSION.SDK_INT >= 29 && checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACTIVITY_RECOGNITION), 2)
            popup("Allow Physical Activity, then tap START WORKOUT again.")
            return
        }
        readSteps { s ->
            Store.p(this).edit().putLong("wstart", System.currentTimeMillis()).putFloat("wbase", s).apply()
            runOnUiThread { render() }
        }
    }

    private fun finishWorkout() {
        val p = Store.p(this)
        val ws = p.getLong("wstart", 0L); val base = p.getFloat("wbase", -1f)
        val mins = (System.currentTimeMillis() - ws) / 60000
        if (mins < 20) { popup("TOO EARLY.\nA real workout takes 20+ minutes. ($mins min so far)"); return }
        readSteps { s ->
            runOnUiThread {
                val steps = if (base < 0 || s < 0) -1 else (s - base).toInt()
                val ok = if (steps < 0) mins >= 40 else steps >= 1500
                p.edit().putLong("wstart", 0L).apply()
                if (ok) Store.complete(this, "workout")
                else { Store.addXp(this, -10); Store.msg(this, "FAKE DETECTED\nOnly $steps steps recorded (need 1500).\n-10 XP") }
                render()
            }
        }
    }

    // ---------- DIET ----------
    private fun numDialog(title: String, key: String, def: Int, lo: Int, hi: Int) {
        val e = EditText(this)
        e.inputType = InputType.TYPE_CLASS_NUMBER
        e.setText(Store.gi(this, key, def).toString())
        AlertDialog.Builder(this).setTitle(title).setView(e)
            .setPositiveButton("Save") { _, _ ->
                val v = e.text.toString().toIntOrNull()
                if (v != null && v in lo..hi) {
                    Store.p(this).edit().putInt(key, v).apply(); Rem.scheduleAll(this); render()
                }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun diet() {
        head("DIET PLAN", "Built from your body stats and school schedule.")
        val p = Store.p(this)
        val pl = Store.plan(this)
        val w = Store.gi(this, "wt", 60); val h = Store.gi(this, "ht", 170)
        val c = card("YOUR PLAN")
        c.t("BMI ${"%.1f".format(pl.bmi)}  (${Store.bmiTag(pl.bmi)})", 14f, TXT, true)
        c.t("${pl.kcal} kcal / day", 24f, ACC, true)
        c.t("Protein ${pl.protein} g   Water ${"%.1f".format(pl.waterMl / 1000.0)} L", 13f, DIM)
        val goal = Store.gi(this, "goal", 1)
        c.b("Weight: $w kg  (tap to edit)") { numDialog("Weight (kg)", "wt", 60, 25, 200) }
        c.b("Height: $h cm  (tap to edit)") { numDialog("Height (cm)", "ht", 170, 100, 230) }
        c.b("Age: ${Store.gi(this, "age", 16)}  (tap to edit)") { numDialog("Age", "age", 16, 8, 80) }
        c.b("Sex: ${if (Store.gi(this, "sex", 0) == 0) "Male" else "Female"}  (tap to switch)") {
            p.edit().putInt("sex", 1 - Store.gi(this, "sex", 0)).apply(); render()
        }
        c.b("Goal: ${listOf("Lose fat", "Maintain", "Gain muscle")[goal]}  (tap to switch)") {
            p.edit().putInt("goal", (goal + 1) % 3).apply(); render()
        }
        val times = Rem.list(this).associate { it.id to it.def }
        Store.MEALS.sortedBy { times[it.rid] }.forEach { m ->
            val tm = times[m.rid]!!
            val mc = card("${m.label.uppercase()}  ${fmt(tm)}")
            mc.t("About ${pl.kcal * m.pct / 100} kcal", 15f, ACC, true)
            mc.t(m.food, 13f, DIM)
            if (Store.logged(this, m.id)) mc.t("✔ LOGGED", 14f, ACC, true)
            else mc.b("I ate this") {
                if (nowMin() in (tm - 30)..(tm + 120)) {
                    p.edit().putBoolean("m_${Store.today()}_${m.id}", true).apply()
                    if (Store.MEALS.all { Store.logged(this, it.id) }) Store.complete(this, "diet")
                } else {
                    Store.addXp(this, -5)
                    popup("OUTSIDE MEAL WINDOW\nLog from 30 min before to 2 h after ${fmt(tm)}. -5 XP")
                }
                render()
            }
        }
    }

    // ---------- FOCUS + SCHEDULE ----------
    private fun timeRow(c: LinearLayout, label: String, key: String, def: Int) {
        val m = Store.gi(this, key, def)
        c.b("$label  ${fmt(m)}") {
            TimePickerDialog(this, { _, hh, mm ->
                Store.p(this).edit().putInt(key, hh * 60 + mm).apply(); Rem.scheduleAll(this); render()
            }, m / 60, m % 60, true).show()
        }
    }

    private fun focus() {
        head("FOCUS GUARD", "Distracting apps are sealed during focus.")
        val p = Store.p(this)
        val now = System.currentTimeMillis()
        val always = p.getBoolean("always", false)
        val until = p.getLong("until", 0L)
        val active = always || until > now
        val fc = card("SESSION")
        fc.t(
            when {
                always -> "STRICT MODE: ALWAYS ON"
                until > now -> "FOCUS ACTIVE: ${(until - now) / 60000 + 1} min left"
                else -> "Focus inactive"
            }, 15f, if (active) RED else DIM, true
        )
        val row = LinearLayout(this)
        listOf(25, 60, 120).forEach { m ->
            val bt = btn("$m min") {
                p.edit().putLong("until", maxOf(until, System.currentTimeMillis()) + m * 60000L)
                    .putInt("pend", Store.gi(this, "pend", 0) + m).apply()
                render()
            }
            bt.gravity = Gravity.CENTER
            val l = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
            l.rightMargin = dp(4)
            row.addView(bt, l)
        }
        fc.addView(row, lp())
        fc.b(if (always) "Strict mode ON (turn off: -50 XP)" else "Strict mode OFF: block all day") {
            if (always) Store.addXp(this, -50)
            p.edit().putBoolean("always", !always).apply(); render()
        }
        if (until > now) fc.b("Quit session (-50 XP, no study credit)") {
            p.edit().putLong("until", 0L).putInt("pend", 0).apply(); Store.addXp(this, -50); render()
        }
        fc.b("Choose blocked apps (${Store.blocked(this).size})") { pick() }

        val sc = card("SCHOOL & COACHING (Mon-Sat)")
        sc.t("Apps are sealed automatically in these hours. Meals, study, workout and water alerts adapt to them.", 12f, DIM)
        timeRow(sc, "School starts", "sS", 480)
        timeRow(sc, "School ends  ", "sE", 870)
        val co = Store.cOn(this)
        sc.b("Coaching: ${if (co) "ON" else "OFF"}  (tap to switch)") {
            p.edit().putBoolean("cOn", !co).apply(); Rem.scheduleAll(this); render()
        }
        if (co) {
            timeRow(sc, "Coaching starts", "cS", 960)
            timeRow(sc, "Coaching ends  ", "cE", 1080)
        }
    }

    private fun pick() {
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        val cur = Store.blocked(this)
        val checked = BooleanArray(apps.size) { apps[it].first in cur }
        AlertDialog.Builder(this)
            .setTitle("Select distractions")
            .setMultiChoiceItems(apps.map { it.second }.toTypedArray(), checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("Save") { _, _ ->
                Store.setBlocked(this, apps.indices.filter { checked[it] }.map { apps[it].first }.toSet())
                render()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- SETUP ----------
    private fun setup() {
        head("SETUP", "Grant these once so the System can work.")
        val on = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)?.contains(packageName) == true
        val c = card("PERMISSIONS")
        if (on) c.t("Focus Guard: ACTIVE ✔", 14f, ACC, true)
        else c.b("1. Enable Focus Guard (Accessibility)") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        c.b("If greyed out: Allow restricted settings") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
        c.b("2. Grant Usage Access (screen time)") { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        c.b("3. Allow Notifications & Physical Activity") {
            val perms = mutableListOf<String>()
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            if (Build.VERSION.SDK_INT >= 29) perms.add(Manifest.permission.ACTIVITY_RECOGNITION)
            if (perms.isNotEmpty()) requestPermissions(perms.toTypedArray(), 3)
        }
        c.b("4. Battery: set Unrestricted (reliable alerts)") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }
}
