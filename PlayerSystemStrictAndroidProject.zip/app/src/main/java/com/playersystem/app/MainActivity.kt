package com.playersystem.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.accessibility.AccessibilityManager
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("player_system", Context.MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private val bg = Color.rgb(8, 12, 25)
    private val panel = Color.rgb(20, 29, 51)
    private val cyan = Color.rgb(83, 214, 255)
    private val white = Color.WHITE
    data class Task(val title: String, val category: String, val xp: Int, val detail: String)
    private val defaults = listOf(
        Task("JEE Physics focus block", "Study", 25, "45 minutes of focused study"),
        Task("JEE Chemistry focus block", "Study", 25, "45 minutes of focused study"),
        Task("JEE Maths practice", "Study", 25, "Solve questions, then check mistakes"),
        Task("School homework", "Study", 20, "Finish highest-priority homework"),
        Task("Workout", "Fitness", 20, "30 minutes; adapt to energy and ability"),
        Task("Log a balanced vegetarian meal", "Nutrition", 10, "Log what you actually ate"),
        Task("Active recall review", "Study", 15, "Review today's learning without notes")
    )
    private fun day() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    private fun xp() = prefs.getInt("xp_${day()}", 0)
    private fun total() = prefs.getInt("total_xp", 0)

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); showHome() }
    private fun base(title: String, sub: String = "") {
        root = LinearLayout(this).apply { orientation = 1; setPadding(18, 20, 18, 24); setBackgroundColor(bg) }
        val sc = ScrollView(this); sc.addView(root); setContentView(sc)
        label(title, 27, cyan, true); if (sub.isNotBlank()) label(sub, 14, Color.LTGRAY); line()
    }
    private fun label(s: String, size: Int = 16, color: Int = white, bold: Boolean = false) {
        root.addView(TextView(this).apply { text=s; textSize=size.toFloat(); setTextColor(color); if (bold) setTypeface(null,1); setPadding(0,6,0,6) })
    }
    private fun line() { root.addView(View(this).apply { setBackgroundColor(Color.rgb(42,60,86)) }, LinearLayout.LayoutParams(-1,1).apply { setMargins(0,9,0,9) }) }
    private fun btn(s: String, f: () -> Unit) {
        root.addView(Button(this).apply { text=s; setTextColor(white); setBackgroundColor(Color.rgb(34,65,103)); setOnClickListener { f() } },
            LinearLayout.LayoutParams(-1,-2).apply { setMargins(0,4,0,4) })
    }
    private fun card(h: String, d: String) { label(h,17,cyan,true); label(d,14,white) }

    private fun showHome() {
        base("PLAYER SYSTEM", "STRICT MODE • Study • Fitness • Discipline")
        label("LEVEL ${total()/100+1}   |   TOTAL XP ${total()}   |   TODAY ${xp()} XP", 16, white, true)
        val enabled = FocusPrefs.isFocusEnabled(this)
        card("FOCUS GUARD: ${if(enabled) "ON" else "OFF"}",
            "Blocked attempts: ${prefs.getInt("blocked_attempts",0)}\nDiscord + Brave blocked in focus mode. YouTube is blocked unless a lecture session is active.")
        btn(if(enabled) "Turn focus guard OFF" else "Enable strict focus guard") {
            FocusPrefs.setFocus(this, !enabled)
            if (!enabled) {
                AlertDialog.Builder(this).setTitle("Enable Accessibility service")
                    .setMessage("Android requires you to enable PLAYER SYSTEM Focus Guard in Accessibility settings. Return here after enabling it. The service can send you Home from selected apps during focus mode.")
                    .setPositiveButton("Open settings") { _, _ -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                    .setNegativeButton("Later", null).show()
            }
            showHome()
        }
        btn("Open Accessibility settings") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn(if(FocusPrefs.isLectureAllowed(this)) "End lecture allowance" else "Start lecture session (allow YouTube)") {
            FocusPrefs.setLecture(this, !FocusPrefs.isLectureAllowed(this))
            Toast.makeText(this, if(FocusPrefs.isLectureAllowed(this)) "Lecture allowance ON. Remember to end it after the lecture." else "Lecture allowance OFF. YouTube will be blocked in focus mode.", Toast.LENGTH_LONG).show()
            showHome()
        }
        btn("Daily quests + XP") { quests() }
        btn("YouTube lecture missions") { lectures() }
        btn("Nutrition + water log") { nutrition() }
        btn("Today's schedule / leave mode") { schedule() }
        btn("Add study reminder (test notification)") { Toast.makeText(this, "Reminder scheduling is planned for the next version; no recurring alarm is set yet.", Toast.LENGTH_LONG).show() }
        label("Strictness note: Android can still allow bypasses through Settings, force-stop, disabling accessibility, or OS restrictions. This is not a tamper-proof kiosk.", 13, Color.YELLOW)
    }

    private fun quests() {
        base("DAILY QUESTS", "Complete only after doing the task.")
        val custom = prefs.getString("custom_tasks", null)
        val tasks = if(custom == null) defaults else {
            val a=JSONArray(custom); (0 until a.length()).map { i -> val o=a.getJSONObject(i); Task(o.optString("title"),o.optString("category","Custom"),o.optInt("xp",15),o.optString("detail","")) }
        }
        tasks.forEach { t ->
            val k="done_${day()}_${t.title}"
            card("${if(prefs.getBoolean(k,false)) "✓ " else ""}${t.title}", "${t.category} • ${t.xp} XP\n${t.detail}")
            if(!prefs.getBoolean(k,false)) btn("Complete +${t.xp} XP") {
                prefs.edit().putBoolean(k,true).putInt("xp_${day()}",xp()+t.xp).putInt("total_xp",total()+t.xp).apply(); quests()
            }
        }
        btn("Add custom quest") { addQuest() }; btn("Back") { showHome() }
    }
    private fun addQuest() {
        val title=EditText(this).apply { hint="Quest title" }; val detail=EditText(this).apply { hint="Details / duration" }
        val layout=LinearLayout(this).apply { orientation=1; setPadding(20,5,20,0); addView(title); addView(detail) }
        AlertDialog.Builder(this).setTitle("New quest").setView(layout).setPositiveButton("Save") { _, _ ->
            val a=JSONArray(prefs.getString("custom_tasks","[]")); a.put(JSONObject().put("title",title.text.toString().ifBlank{"Custom quest"}).put("detail",detail.text.toString()).put("xp",15).put("category","Custom"))
            prefs.edit().putString("custom_tasks",a.toString()).apply(); quests()
        }.setNegativeButton("Cancel",null).show()
    }
    private fun lectures() {
        base("LECTURE MISSIONS", "YouTube is allowed only while you manually enable lecture mode.")
        val a=JSONArray(prefs.getString("lectures","[]"))
        for(i in 0 until a.length()) {
            val o=a.getJSONObject(i); card(o.optString("chapter","Lecture"), "${o.optInt("minutes",30)} min • ${if(o.optBoolean("done")) "Completed" else "Pending"}")
            btn("Open ${o.optString("chapter","lecture")}") { try { startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(o.optString("url")))) } catch(_:Exception){} }
            if(!o.optBoolean("done")) btn("Mark lecture complete (+15 XP)") { o.put("done",true); a.put(i,o); prefs.edit().putString("lectures",a.toString()).putInt("xp_${day()}",xp()+15).putInt("total_xp",total()+15).apply(); lectures() }
        }
        btn("Add lecture URL") {
            val url=EditText(this).apply{hint="YouTube URL"}; val chapter=EditText(this).apply{hint="Subject / chapter"}; val mins=EditText(this).apply{hint="Target minutes";inputType=2}
            val l=LinearLayout(this).apply{orientation=1;setPadding(20,5,20,0);addView(url);addView(chapter);addView(mins)}
            AlertDialog.Builder(this).setTitle("New lecture").setView(l).setPositiveButton("Save"){_,_->a.put(JSONObject().put("url",url.text.toString()).put("chapter",chapter.text.toString()).put("minutes",mins.text.toString().toIntOrNull()?:30).put("done",false));prefs.edit().putString("lectures",a.toString()).apply();lectures()}.setNegativeButton("Cancel",null).show()
        }
        btn("Back") { showHome() }
    }
    private fun nutrition() {
        base("NUTRITION LOG", "Flexible vegetarian meals; no restrictive targets.")
        listOf("Breakfast","Lunch","Dinner","Snack").forEach { meal ->
            val old=prefs.getString("meal_${day()}_$meal","Not logged")
            btn("$meal: $old") {
                val e=EditText(this).apply{hint="e.g. dal, roti, rice, curd"}
                AlertDialog.Builder(this).setTitle("Log $meal").setView(e).setPositiveButton("Save"){_,_->prefs.edit().putString("meal_${day()}_$meal",e.text.toString()).apply();nutrition()}.setNegativeButton("Cancel",null).show()
            }
        }
        btn("Log a glass of water") { val n=prefs.getInt("water_${day()}",0)+1; prefs.edit().putInt("water_${day()}",n).apply(); Toast.makeText(this,"Water logged: $n",Toast.LENGTH_SHORT).show() }
        btn("Back") { showHome() }
    }
    private fun schedule() {
        base("ADAPTIVE SCHEDULE", "School 08:00–15:00 Mon–Sat • Coaching 16:30–19:40 Mon/Tue/Thu/Fri • 20 min travel")
        val leave=prefs.getBoolean("leave_${day()}",false)
        card("MODE",if(leave) "Leave mode active: prioritize study, breaks, meals and workout." else "Normal day")
        btn("Toggle leave mode") { prefs.edit().putBoolean("leave_${day()}",!leave).apply(); schedule() }
        val lines=if(leave) listOf("07:00 Wake + breakfast","08:00–09:00 JEE priority chapter","09:15–10:00 Homework","10:15–11:00 Practice questions","11:00 Break","12:00 Lunch","13:00–14:00 Lecture/backlog","15:00–15:30 Workout","Evening review + rest","Protect adequate sleep")
        else listOf("07:00 Wake + breakfast","08:00–15:00 School","15:00–15:20 Travel","15:20–16:10 Meal + rest","Coaching days: 16:30–19:40 coaching (travel buffer needed)","Evening: dinner + 1–2 h homework/review","30 min workout in a realistic free slot","Bedtime currently set to 00:00")
        lines.forEach{label("• $it")}
        btn("Back") { showHome() }
    }
}
