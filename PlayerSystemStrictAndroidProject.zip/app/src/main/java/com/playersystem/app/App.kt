package com.playersystem.app

import android.app.Application
import android.util.Log

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { getSharedPreferences("crash", MODE_PRIVATE).edit().putString("t", Log.getStackTraceString(e)).commit() } catch (x: Throwable) {}
            old?.uncaughtException(t, e)
        }
    }
}
