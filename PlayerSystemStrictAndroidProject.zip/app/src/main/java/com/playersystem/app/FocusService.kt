package com.playersystem.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class FocusService : AccessibilityService() {
    private var lastHit = 0L

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) return
        val p = Store.p(this)
        val active = p.getBoolean("always", false) || p.getLong("until", 0L) > System.currentTimeMillis() || Store.inSchool(this)
        if (!active || pkg !in Store.blocked(this)) return
        val now = System.currentTimeMillis()
        if (now - lastHit < 1500) return
        lastHit = now
        Store.addBlock(this)
        Store.addXp(this, -5)
        performGlobalAction(GLOBAL_ACTION_HOME)
        startActivity(Intent(this, BlockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    override fun onInterrupt() {}
}
