package com.playersystem.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class BlockActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.gravity = Gravity.CENTER
        l.setBackgroundColor(0xFF05070D.toInt())
        l.setPadding(60, 60, 60, 60)
        fun t(s: String, sz: Float, col: Int) {
            val v = TextView(this)
            v.text = s; v.textSize = sz; v.setTextColor(col); v.gravity = Gravity.CENTER
            v.setPadding(0, 20, 0, 20)
            l.addView(v)
        }
        t("[ SYSTEM ]", 16f, 0xFF2EA8FF.toInt())
        t("ACCESS DENIED", 32f, 0xFFFF4D5E.toInt())
        t("This gate is sealed.\n-5 XP\n\nA Player does not quit.\nReturn to your quest.", 16f, 0xFFE6F1FF.toInt())
        val btn = Button(this)
        btn.text = "RETURN"
        btn.setOnClickListener { goHome() }
        l.addView(btn)
        setContentView(l)
    }

    private fun goHome() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { goHome() }
}
