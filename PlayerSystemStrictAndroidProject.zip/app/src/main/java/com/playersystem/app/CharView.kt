package com.playersystem.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.sin

class CharView(c: Context, private val col: Int, private val power: Int, private val knight: Boolean) : View(c) {
    private val pa = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f)

    init {
        anim.duration = 3200
        anim.repeatCount = ValueAnimator.INFINITE
        anim.interpolator = LinearInterpolator()
        anim.addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    private fun al(c: Int, a: Float) = (c and 0xFFFFFF) or (a.coerceIn(0f, 255f).toInt() shl 24)

    private fun glowDot(cv: Canvas, x: Float, y: Float, r: Float) {
        pa.shader = RadialGradient(x, y, r * 3, intArrayOf(al(col, 220), 0), null, Shader.TileMode.CLAMP)
        cv.drawCircle(x, y, r * 3, pa); pa.shader = null
        pa.color = 0xFFFFFFFF.toInt(); cv.drawCircle(x, y, r, pa)
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val u = h / 100f; val cx = w / 2
        val pulse = 0.5f + 0.5f * sin(t * 2f * PI.toFloat())
        pa.style = Paint.Style.FILL
        pa.shader = RadialGradient(cx, 58 * u, 62 * u, intArrayOf(al(col, 60 + 90 * pulse), 0), null, Shader.TileMode.CLAMP)
        cv.drawCircle(cx, 58 * u, 62 * u, pa); pa.shader = null
        for (i in 0 until 16) {
            val ph = (t + i / 16f) % 1f
            pa.color = al(col, (1f - ph) * 220)
            cv.drawCircle(cx + sin(i * 7.3f) * w * 0.38f, h * (1f - ph), (1.5f + i % 3) * u * 0.45f, pa)
        }
        val s = if (knight) 0.85f else 1f
        val body = Path()
        body.moveTo(cx, 20 * u)
        body.quadTo(cx + 24 * u * s, 28 * u, cx + 30 * u * s, 62 * u)
        body.lineTo(cx + 38 * u * s, 98 * u); body.lineTo(cx - 38 * u * s, 98 * u)
        body.lineTo(cx - 30 * u * s, 62 * u)
        body.quadTo(cx - 24 * u * s, 28 * u, cx, 20 * u); body.close()
        pa.color = 0xFF03060C.toInt(); cv.drawPath(body, pa)
        pa.style = Paint.Style.STROKE; pa.strokeWidth = 2.5f; pa.color = al(col, 150 + 100 * pulse)
        cv.drawPath(body, pa)
        if (knight) {
            pa.style = Paint.Style.FILL; pa.color = 0xFF05080F.toInt()
            val helm = RectF(cx - 11 * u, 18 * u, cx + 11 * u, 46 * u)
            cv.drawRoundRect(helm, 4 * u, 4 * u, pa)
            pa.style = Paint.Style.STROKE; pa.color = al(col, 200); cv.drawRoundRect(helm, 4 * u, 4 * u, pa)
            pa.style = Paint.Style.FILL; pa.color = al(col, 180 + 70 * pulse)
            cv.drawRect(cx - 8 * u, 30 * u, cx + 8 * u, 33 * u, pa)
            val plume = Path()
            plume.moveTo(cx - 3 * u, 18 * u); plume.lineTo(cx + 8 * u, 4 * u); plume.lineTo(cx + 5 * u, 18 * u); plume.close()
            pa.color = al(col, 220); cv.drawPath(plume, pa)
            pa.style = Paint.Style.STROKE; pa.strokeWidth = 4f; pa.color = al(col, 230)
            cv.drawLine(cx + 34 * u * s, 52 * u, cx + 34 * u * s, 98 * u, pa)
            cv.drawLine(cx + 28 * u * s, 58 * u, cx + 40 * u * s, 58 * u, pa)
        } else {
            pa.style = Paint.Style.FILL; pa.color = 0xFF000000.toInt()
            cv.drawOval(RectF(cx - 10 * u, 26 * u, cx + 10 * u, 50 * u), pa)
            glowDot(cv, cx - 4.5f * u, 38 * u, 1.3f * u)
            glowDot(cv, cx + 4.5f * u, 38 * u, 1.3f * u)
            pa.style = Paint.Style.STROKE; pa.strokeWidth = 3f; pa.color = al(col, 230)
            cv.drawLine(cx - 34 * u, 70 * u, cx - 41 * u, 94 * u, pa)
            cv.drawLine(cx + 34 * u, 70 * u, cx + 41 * u, 94 * u, pa)
            pa.style = Paint.Style.FILL; pa.color = al(col, 200 + 55 * pulse)
            for (i in 0 until power) {
                val x = cx + (i - (power - 1) / 2f) * 7 * u
                val y = 9 * u - 2 * u * pulse
                val d = Path()
                d.moveTo(x, y - 3 * u); d.lineTo(x + 2 * u, y); d.lineTo(x, y + 3 * u); d.lineTo(x - 2 * u, y); d.close()
                cv.drawPath(d, pa)
            }
        }
    }
}
