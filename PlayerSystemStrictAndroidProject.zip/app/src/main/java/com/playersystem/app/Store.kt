package com.playersystem.app

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class Q(val id: String, val title: String, val xp: Int, val stat: String)
data class Meal(val rid: Int, val id: String, val label: String, val pct: Int, val food: String)
class Sold(val name: String, val lv: Int, val role: String, val line: String)
class Plan(val bmi: Double, val bmr: Int, val kcal: Int, val protein: Int, val waterMl: Int)

object Store {
    val QUESTS = listOf(
        Q("workout", "Workout: 100 push-ups, 100 sit-ups, 100 squats, 10 km run", 40, "STR"),
        Q("study", "Study: 2 hours of completed focus sessions", 40, "INT"),
        Q("diet", "Diet: log all 4 meals on time", 25, "VIT"),
        Q("water", "Water: drink your daily target", 15, "VIT"),
        Q("sleep", "Sleep: claim between 9:00 and 11:30 PM", 20, "VIT")
    )
    val MEALS = listOf(
        Meal(3, "bf", "Breakfast", 25, "Oats or poha + 3 eggs/paneer + banana + milk."),
        Meal(4, "lu", "Lunch", 30, "Roti/rice + dal + sabzi + curd + chicken/paneer."),
        Meal(10, "sn", "Snack", 15, "Peanuts/chana + a fruit + milk or shake."),
        Meal(5, "dn", "Dinner", 30, "2-3 roti + dal/eggs/chicken + veggies + salad.")
    )
    val DEFAULT_BLOCKED = setOf(
        "com.instagram.android", "com.facebook.katana", "com.zhiliaoapp.musically",
        "com.google.android.youtube", "com.twitter.android", "com.snapchat.android",
        "com.reddit.frontpage", "in.mohalla.sharechat", "com.netflix.mediaclient",
        "com.facebook.orca", "com.pinterest"
    )

    val ARMY = listOf(
        Sold("Fang", 2, "Scout", "Silent and quick. He watches the gate while you rest."),
        Sold("Vorn", 5, "Knight", "Armor heavy as your excuses. He carries both."),
        Sold("Nyx", 10, "Assassin", "She cuts the habits you refuse to cut."),
        Sold("Titan", 15, "Guardian", "He stands where your discipline used to break."),
        Sold("Seraph", 25, "Archer", "Every arrow is a goal you finally aimed at."),
        Sold("Umbra", 40, "Marshal", "He commands the army you built from sweat.")
    )
    fun armyCount(c: Context) = ARMY.count { level(c) >= it.lv }
    fun title(l: Int) = when { l < 2 -> "Rookie Hunter"; l < 5 -> "Awakened"; l < 10 -> "Gate Runner"; l < 20 -> "Elite Hunter"; l < 35 -> "Shadow Commander"; else -> "Sovereign" }

    fun p(c: Context) = c.getSharedPreferences("system", Context.MODE_PRIVATE)
    fun gi(c: Context, k: String, d: Int) = p(c).getInt(k, d)
    fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    fun xp(c: Context) = p(c).getInt("xp", 0)
    fun level(c: Context) = 1 + xp(c) / 100
    fun rank(l: Int) = when { l < 5 -> "E"; l < 10 -> "D"; l < 20 -> "C"; l < 35 -> "B"; l < 50 -> "A"; else -> "S" }
    fun addXp(c: Context, n: Int) { p(c).edit().putInt("xp", maxOf(0, xp(c) + n)).apply() }
    fun done(c: Context, id: String) = p(c).getBoolean("q_${today()}_$id", false)
    fun stat(c: Context, s: String) = p(c).getInt("s_$s", 0)
    fun fm(c: Context) = p(c).getInt("fm_${today()}", 0)
    fun glasses(c: Context) = p(c).getInt("w_${today()}", 0)
    fun logged(c: Context, id: String) = p(c).getBoolean("m_${today()}_$id", false)

    fun msg(c: Context, m: String) {
        val o = p(c).getString("msg", "") ?: ""
        p(c).edit().putString("msg", if (o.isEmpty()) m else "$o\n\n$m").apply()
    }

    fun complete(c: Context, id: String) {
        if (done(c, id)) return
        val q = QUESTS.first { it.id == id }
        val l0 = level(c)
        p(c).edit().putBoolean("q_${today()}_$id", true).putInt("s_${q.stat}", stat(c, q.stat) + 1).apply()
        val gain = q.xp * (100 + 5 * armyCount(c)) / 100
        addXp(c, gain)
        val l1 = level(c)
        msg(c, "QUEST COMPLETE\n${q.title.substringBefore(':')}  +$gain XP" + if (l1 > l0) "\n\nLEVEL UP!  LV $l1" else "")
    }

    fun settle(c: Context) {
        val pend = gi(c, "pend", 0)
        if (pend > 0 && System.currentTimeMillis() >= p(c).getLong("until", 0L)) {
            p(c).edit().putInt("fm_${today()}", fm(c) + pend).putInt("pend", 0).apply()
            if (fm(c) >= 120) complete(c, "study")
        }
    }

    fun blocks(c: Context) = gi(c, "b_${today()}", 0)
    fun addBlock(c: Context) { p(c).edit().putInt("b_${today()}", blocks(c) + 1).apply() }
    fun blocked(c: Context): Set<String> = p(c).getStringSet("blocked", DEFAULT_BLOCKED)!!.toSet()
    fun setBlocked(c: Context, s: Set<String>) { p(c).edit().putStringSet("blocked", s).apply() }

    fun sch(c: Context) = intArrayOf(gi(c, "sS", 480), gi(c, "sE", 870), gi(c, "cS", 960), gi(c, "cE", 1080))
    fun cOn(c: Context) = p(c).getBoolean("cOn", true)
    fun inSchool(c: Context): Boolean {
        val cal = Calendar.getInstance()
        if (cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) return false
        val m = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val s = sch(c)
        return m in s[0] until s[1] || (cOn(c) && m in s[2] until s[3])
    }

    fun plan(c: Context): Plan {
        val w = gi(c, "wt", 60); val h = gi(c, "ht", 170); val a = gi(c, "age", 16)
        val male = gi(c, "sex", 0) == 0
        val bmr = (10 * w + 6.25 * h - 5 * a + (if (male) 5 else -161)).toInt()
        val adj = when (gi(c, "goal", 1)) { 0 -> -400; 2 -> 350; else -> 0 }
        val hm = h / 100.0
        return Plan(w / (hm * hm), bmr, (bmr * 1.55).toInt() + adj, (w * 1.8).toInt(), w * 35)
    }
    fun bmiTag(b: Double) = when { b < 18.5 -> "Underweight"; b < 25 -> "Normal"; b < 30 -> "Overweight"; else -> "Obese" }

    fun rollover(c: Context) {
        val last = p(c).getString("last", "") ?: ""
        val t = today()
        if (last == t) return
        var pen = 0
        if (last != "") {
            val dn = QUESTS.count { p(c).getBoolean("q_${last}_${it.id}", false) }
            pen = (QUESTS.size - dn) * 10
            addXp(c, -pen)
            p(c).edit().putInt("streak", if (dn >= 3) gi(c, "streak", 0) + 1 else 0).apply()
        }
        p(c).edit().putString("last", t).putInt("pen", pen).apply()
    }
}
